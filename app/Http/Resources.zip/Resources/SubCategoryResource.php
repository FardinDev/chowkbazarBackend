<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class SubCategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {

        if ($this->childs) {
            return [
                // 'id' => $this->id,
                'label' => $this->name,
                'url' => 'shop/catalog/'.$this->id,
                'items' => SubCategoryResource::collection($this->childs)
            ];
        } else {
            return [
                // 'id' => $this->id,
                'label' => $this->name,
                'url' => 'shop/catalog/'.$this->id
            ];
        }
        
  
    }
}
