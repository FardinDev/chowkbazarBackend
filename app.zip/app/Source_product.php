<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Source_product extends Model
{
    protected $table = 'source_products';

    protected $guarded = [];
}
