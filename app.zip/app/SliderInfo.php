<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderInfo extends Model
{
    //
}
