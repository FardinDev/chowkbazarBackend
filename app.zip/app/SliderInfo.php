<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Resizable;

class SliderInfo extends Model
{
    use Resizable;
    
    // protected $table = 'slider_infos';
}
