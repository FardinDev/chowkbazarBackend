<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Source_product_file extends Model
{
    protected $table = 'source_product_files';

    protected $guarded = [];
}
