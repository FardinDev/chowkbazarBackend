<div class="recommended_items">
    <!--recommended_items-->
    

    <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div style="height:15px"></div>
            <div class="item active" id="active-r">

            </div>
        </div>
    </div>
</div>
<!--/recommended_items-->
